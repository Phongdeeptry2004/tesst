          <!-- Container fluid  -->
          <div class="container-fluid">
              <h1>Thống Kê Doanh Thu</h1>
              <div id="chart" style="height: 250px;"></div>
              <h1>Thống Kê Đơn Hàng</h1>
              <div id="chart1" style="height: 250px;"></div>

          </div>

          <!-- End Container fluid  -->