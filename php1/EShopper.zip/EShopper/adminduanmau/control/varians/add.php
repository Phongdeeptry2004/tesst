<div class="container-fluid">
    <form method="post" action="index.php?act=addcolor">
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">Color</label>
            <input type="text" class="form-control" name='color' id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <button type="submit" class="btn btn-primary">Thêm</button>
    </form>
    <form method="post" action="index.php?act=addsize">
        <div class="mb-3">
            <label for="exampleInputEmail1" class="form-label">size</label>
            <input type="text" class="form-control" name='size' id="exampleInputEmail1" aria-describedby="emailHelp">
        </div>
        <button type="submit" class="btn btn-primary">Thêm</button>
    </form>
</div>